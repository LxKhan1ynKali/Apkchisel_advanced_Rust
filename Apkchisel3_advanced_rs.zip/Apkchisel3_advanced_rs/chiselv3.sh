#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN="$PROJECT_DIR/binaries/chiselv3"

banner() {
  cat <<'EOF'
  ██████╗██╗  ██╗██╗███████╗███████╗██╗   ██╗██╗
 ██╔════╝██║  ██║██║██╔════╝██╔════╝██║   ██║██║
 ██║     ███████║██║███████╗█████╗  ██║   ██║██║
 ██║     ██╔══██║██║╚════██║██╔══╝  ╚██╗ ██╔╝██║
 ╚██████╗██║  ██║██║███████║███████╗ ╚████╔╝ ███████╗
  ╚═════╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝  ╚═══╝  ╚══════╝
  chiselv3  |  Khaninkali (HyperSecurity)
EOF
}

banner

if [[ ! -x "$BIN" ]]; then
  echo "[!] Binary not found: $BIN"
  echo "[+] Building now..."
  "$PROJECT_DIR/build.sh"
fi

exec "$BIN" "$@"
