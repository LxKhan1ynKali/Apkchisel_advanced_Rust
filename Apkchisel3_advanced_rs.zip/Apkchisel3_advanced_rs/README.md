# Apkchisel3 Advanced (Rust)

Author: **Khaninkali** (HyperSecurity)

A defensive, CLI-based reverse-engineering helper for **APK** and **IPA** artifacts.

## What this tool does
- Lists contents of APK/IPA archives (ZIP-based formats)
- Extracts archives to a chosen directory
- Computes SHA-256 hashes (single file or whole extracted trees)
- Produces a JSON report with basic metadata
- Optionally orchestrates external analyzers if they exist on PATH (e.g., `apktool`, `jadx`, `aapt2`, `yara`)

## What this tool does NOT do
- It is **not** an exploit framework.
- It does **not** perform offensive operations.
- Any “malware detection” is limited to *defensive heuristics* and/or calling **external scanners** you already have installed.

## Build
```bash
cargo build --release
```

## Usage
```bash
# generate a report
./target/release/chisel3v scan --input sample.apk --out ./analysis

# list archive contents
./target/release/chiselv3 list --input sample.apk

# extract
./target/release/chiselv3 extract --input sample.apk --out ./analysis/extracted

# tech fingerprinting + optional local CVE mapping (defensive)
./target/release/apkchisel3_advanced_rs fingerprint \
  --url "https://example.com" \
  --cve-db ./cve_map.json
```
