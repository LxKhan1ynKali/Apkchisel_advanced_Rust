pub fn print() {
    // Minimal, fast banner (no ANSI required).
    println!("chiselv3 | Khaninkali (HyperSecurity)");
    println!("--------------------------------");
}
