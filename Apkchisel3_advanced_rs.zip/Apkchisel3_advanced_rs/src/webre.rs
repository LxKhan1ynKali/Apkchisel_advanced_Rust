use crate::urlre;
use anyhow::{Context, Result};
use regex::Regex;
use scraper::{Html, Selector};
use serde::Serialize;
use std::collections::BTreeSet;
use std::path::Path;
use url::Url;

#[derive(Debug, Serialize)]
pub struct HtmlAnalysis {
    pub url: String,
    pub final_url: Option<String>,
    pub status_chain: Vec<u16>,

    pub title: Option<String>,
    pub meta_refresh: Option<String>,

    pub forms: Vec<FormInfo>,
    pub script_snippets: Vec<String>,

    pub extracted_urls: Vec<String>,
    pub extracted_domains: Vec<String>,

    pub warnings: Vec<String>,
}

#[derive(Debug, Serialize)]
pub struct FormInfo {
    pub action: Option<String>,
    pub method: Option<String>,
    pub input_names: Vec<String>,
    pub password_inputs: usize,
}

fn text_limit(s: &str, max: usize) -> String {
    if s.len() <= max {
        s.to_string()
    } else {
        format!("{}...", &s[..max])
    }
}

/// Fetches a page (GET) with strict size limit, then runs static HTML analysis.
/// This is for *defensive investigation* only.
pub fn analyze_html(url: &str, max_bytes: usize, timeout_secs: u64) -> Result<HtmlAnalysis> {
    // Reuse the redirect chain logic from fetch_metadata, but we also need body.
    let meta = urlre::fetch_metadata(url, 8, timeout_secs).context("fetch metadata")?;
    let final_url = meta.final_url.clone().unwrap_or_else(|| url.to_string());
    let status_chain = meta.chain.iter().map(|h| h.status).collect::<Vec<_>>();

    let client = reqwest::blocking::Client::builder()
        .redirect(reqwest::redirect::Policy::limited(0))
        .timeout(std::time::Duration::from_secs(timeout_secs))
        .user_agent("apkchisel3/defensive-html-analyzer")
        .build()?;

    let mut warnings = Vec::new();
    let mut resp = client.get(&final_url).send()?;
    let status = resp.status().as_u16();
    if !(200..300).contains(&status) {
        warnings.push(format!("non_2xx_status:{}", status));
    }

    let mut buf = Vec::new();
    resp.copy_to(&mut buf)
        .with_context(|| format!("read response body from {final_url}"))?;

    if buf.len() > max_bytes {
        warnings.push(format!("body_truncated:{}>{}", buf.len(), max_bytes));
        buf.truncate(max_bytes);
    }

    let body = String::from_utf8_lossy(&buf).to_string();
    let doc = Html::parse_document(&body);

    // Title
    let title_sel = Selector::parse("title").unwrap();
    let title = doc
        .select(&title_sel)
        .next()
        .map(|n| n.text().collect::<String>().trim().to_string())
        .filter(|s| !s.is_empty());

    // Meta refresh
    let meta_sel = Selector::parse("meta").unwrap();
    let meta_refresh = doc.select(&meta_sel).find_map(|m| {
        let http_equiv = m.value().attr("http-equiv").unwrap_or("").to_lowercase();
        if http_equiv == "refresh" {
            m.value().attr("content").map(|c| c.to_string())
        } else {
            None
        }
    });

    // Forms analysis
    let form_sel = Selector::parse("form").unwrap();
    let input_sel = Selector::parse("input").unwrap();
    let mut forms = Vec::new();

    for f in doc.select(&form_sel) {
        let action = f.value().attr("action").map(|s| s.to_string());
        let method = f
            .value()
            .attr("method")
            .map(|s| s.to_lowercase())
            .or(Some("get".to_string()));

        let mut input_names = Vec::new();
        let mut pw = 0usize;
        for i in f.select(&input_sel) {
            if let Some(name) = i.value().attr("name") {
                input_names.push(name.to_string());
            }
            if i.value().attr("type").unwrap_or("").eq_ignore_ascii_case("password") {
                pw += 1;
            }
        }

        if pw > 0 {
            warnings.push("password_form_present".to_string());
        }

        forms.push(FormInfo {
            action,
            method,
            input_names,
            password_inputs: pw,
        });
    }

    // JS redirect-ish patterns
    let mut script_snippets = Vec::new();
    let re = Regex::new(r"(?i)(window\.location|document\.location|location\.href)\s*=")?;
    for cap in re.find_iter(&body).take(5) {
        let start = cap.start().saturating_sub(60);
        let end = (cap.end() + 160).min(body.len());
        script_snippets.push(text_limit(&body[start..end], 300));
    }

    // Extract URLs from href/src and from plain text (regex)
    let mut urls: BTreeSet<String> = BTreeSet::new();

    let a_sel = Selector::parse("a[href]").unwrap();
    for a in doc.select(&a_sel) {
        if let Some(h) = a.value().attr("href") {
            urls.insert(h.to_string());
        }
    }
    let img_sel = Selector::parse("img[src]").unwrap();
    for i in doc.select(&img_sel) {
        if let Some(s) = i.value().attr("src") {
            urls.insert(s.to_string());
        }
    }

    let url_re = Regex::new(r#"https?://[^\s"'<>]+"#)?;
    for m in url_re.find_iter(&body).take(200) {
        urls.insert(m.as_str().to_string());
    }

    // Normalize/resolve relative URLs
    let base = Url::parse(&final_url)?;
    let mut normalized_urls: BTreeSet<String> = BTreeSet::new();
    for u in urls {
        if let Ok(joined) = base.join(&u) {
            normalized_urls.insert(joined.to_string());
        } else if let Ok(parsed) = Url::parse(&u) {
            normalized_urls.insert(parsed.to_string());
        }
    }

    let mut domains: BTreeSet<String> = BTreeSet::new();
    for u in &normalized_urls {
        if let Ok(p) = Url::parse(u) {
            if let Some(h) = p.host_str() {
                domains.insert(h.to_string());
            }
        }
    }

    Ok(HtmlAnalysis {
        url: url.to_string(),
        final_url: Some(final_url),
        status_chain,
        title,
        meta_refresh,
        forms,
        script_snippets,
        extracted_urls: normalized_urls.into_iter().collect(),
        extracted_domains: domains.into_iter().collect(),
        warnings,
    })
}

#[derive(Debug, Serialize)]
pub struct IocExport {
    pub input: String,
    pub urls: Vec<String>,
    pub domains: Vec<String>,
    pub ips: Vec<String>,
}

pub fn iocs_from_url(url: &str) -> Result<IocExport> {
    let ind = urlre::analyze_url(url)?;
    let mut urls = BTreeSet::new();
    let mut domains = BTreeSet::new();
    let mut ips = BTreeSet::new();

    if let Some(n) = ind.normalized {
        urls.insert(n.clone());
        if let Ok(p) = Url::parse(&n) {
            if let Some(h) = p.host_str() {
                domains.insert(h.to_string());
                if let Ok(ip) = h.parse::<std::net::IpAddr>() {
                    ips.insert(ip.to_string());
                }
            }
        }
    }

    if let Some(h) = ind.host_ascii {
        domains.insert(h);
    }
    if let Some(h) = ind.host_unicode {
        domains.insert(h);
    }

    Ok(IocExport {
        input: url.to_string(),
        urls: urls.into_iter().collect(),
        domains: domains.into_iter().collect(),
        ips: ips.into_iter().collect(),
    })
}

pub fn write_iocs_csv(path: &Path, iocs: &IocExport) -> Result<()> {
    let mut w = csv::Writer::from_path(path)
        .with_context(|| format!("open csv {}", path.display()))?;

    w.write_record(["type", "value"])?;
    for u in &iocs.urls {
        w.write_record(["url", u])?;
    }
    for d in &iocs.domains {
        w.write_record(["domain", d])?;
    }
    for ip in &iocs.ips {
        w.write_record(["ip", ip])?;
    }
    w.flush()?;
    Ok(())
}
