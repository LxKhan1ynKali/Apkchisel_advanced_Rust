use anyhow::{Context, Result};
use once_cell::sync::Lazy;
use regex::Regex;
use scraper::{Html, Selector};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;
use url::Url;

#[derive(Debug, Serialize)]
pub struct FingerprintReport {
    pub author: String,
    pub url: String,
    pub final_url: String,
    pub status: u16,

    pub headers: BTreeMap<String, String>,
    pub title: Option<String>,

    pub tech: Vec<TechFinding>,
    pub possible_exposure: Vec<ExposureFinding>,

    pub warnings: Vec<String>,
}

#[derive(Debug, Serialize, Clone)]
pub struct TechFinding {
    pub product: String,
    pub confidence: String,
    pub evidence: Vec<String>,
    pub version: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct ExposureFinding {
    pub product: String,
    pub detected_version: Option<String>,
    pub matches: Vec<CveItem>,
    pub note: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct CveItem {
    pub id: String,
    pub severity: Option<String>,
    pub title: Option<String>,
    pub url: Option<String>,
    pub notes: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct CveDb {
    pub version: u32,
    pub entries: Vec<CveEntry>,
}

#[derive(Debug, Deserialize)]
pub struct CveEntry {
    pub product: String,
    pub r#match: CveMatch,
    pub cves: Vec<CveItem>,
}

#[derive(Debug, Deserialize)]
pub struct CveMatch {
    #[serde(default)]
    pub version_regex: Option<String>,
}

static RE_WORDPRESS_GENERATOR: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r#"(?i)<meta[^>]+name=\"generator\"[^>]+content=\"WordPress\s*([^\"]*)\""#)
        .unwrap()
});
static RE_JOOMLA_GENERATOR: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r#"(?i)<meta[^>]+name=\"generator\"[^>]+content=\"Joomla!\s*([^\"]*)\""#)
        .unwrap()
});
static RE_DRUPAL: Lazy<Regex> = Lazy::new(|| Regex::new(r#"(?i)Drupal"#).unwrap());
static RE_REACT: Lazy<Regex> = Lazy::new(|| Regex::new(r#"(?i)react"#).unwrap());
static RE_NEXTJS: Lazy<Regex> = Lazy::new(|| Regex::new(r#"(?i)__NEXT_DATA__"#).unwrap());
static RE_VUE: Lazy<Regex> = Lazy::new(|| Regex::new(r#"(?i)vue"#).unwrap());
static RE_NGINX: Lazy<Regex> = Lazy::new(|| Regex::new(r#"(?i)nginx"#).unwrap());
static RE_APACHE: Lazy<Regex> = Lazy::new(|| Regex::new(r#"(?i)apache"#).unwrap());
static RE_SERVER_VERSION: Lazy<Regex> = Lazy::new(|| Regex::new(r#"(?i)(apache|nginx)/([0-9]+(?:\.[0-9]+){0,3})"#).unwrap());

fn header_map(resp: &reqwest::blocking::Response) -> BTreeMap<String, String> {
    let mut out = BTreeMap::new();
    for (k, v) in resp.headers().iter() {
        if let Ok(s) = v.to_str() {
            out.insert(k.to_string(), s.to_string());
        }
    }
    out
}

fn extract_title(doc: &Html) -> Option<String> {
    let sel = Selector::parse("title").ok()?;
    doc.select(&sel)
        .next()
        .map(|n| n.text().collect::<String>().trim().to_string())
        .filter(|s| !s.is_empty())
}

fn detect_from_headers(headers: &BTreeMap<String, String>) -> Vec<TechFinding> {
    let mut findings: Vec<TechFinding> = Vec::new();

    let server = headers
        .get("server")
        .map(|s| s.to_string())
        .unwrap_or_default();

    if !server.is_empty() {
        if RE_NGINX.is_match(&server) {
            let version = RE_SERVER_VERSION
                .captures(&server)
                .and_then(|c| c.get(2).map(|m| m.as_str().to_string()));
            findings.push(TechFinding {
                product: "nginx".to_string(),
                confidence: "high".to_string(),
                evidence: vec![format!("server_header:{server}")],
                version,
            });
        }
        if RE_APACHE.is_match(&server) {
            let version = RE_SERVER_VERSION
                .captures(&server)
                .and_then(|c| c.get(2).map(|m| m.as_str().to_string()));
            findings.push(TechFinding {
                product: "apache".to_string(),
                confidence: "high".to_string(),
                evidence: vec![format!("server_header:{server}")],
                version,
            });
        }
    }

    if let Some(xp) = headers.get("x-powered-by") {
        // Common patterns like PHP/8.2, Express, ASP.NET
        findings.push(TechFinding {
            product: "x-powered-by".to_string(),
            confidence: "medium".to_string(),
            evidence: vec![format!("x-powered-by:{xp}")],
            version: None,
        });

        if xp.to_lowercase().contains("express") {
            findings.push(TechFinding {
                product: "express".to_string(),
                confidence: "medium".to_string(),
                evidence: vec![format!("x-powered-by:{xp}")],
                version: None,
            });
        }
        if xp.to_lowercase().contains("asp.net") {
            findings.push(TechFinding {
                product: "asp.net".to_string(),
                confidence: "medium".to_string(),
                evidence: vec![format!("x-powered-by:{xp}")],
                version: None,
            });
        }
        if xp.to_lowercase().contains("php") {
            // Attempt a naive parse for PHP/x.y
            let ver = Regex::new(r#"(?i)php/([0-9]+(?:\.[0-9]+){1,3})"#)
                .ok()
                .and_then(|re| re.captures(xp))
                .and_then(|c| c.get(1).map(|m| m.as_str().to_string()));
            findings.push(TechFinding {
                product: "php".to_string(),
                confidence: "medium".to_string(),
                evidence: vec![format!("x-powered-by:{xp}")],
                version: ver,
            });
        }
    }

    findings
}

fn detect_from_html(body: &str, doc: &Html) -> Vec<TechFinding> {
    let mut findings: Vec<TechFinding> = Vec::new();

    if let Some(c) = RE_WORDPRESS_GENERATOR.captures(body) {
        let ver = c.get(1).map(|m| m.as_str().trim().to_string()).filter(|s| !s.is_empty());
        findings.push(TechFinding {
            product: "wordpress".to_string(),
            confidence: "high".to_string(),
            evidence: vec!["meta_generator:WordPress".to_string()],
            version: ver,
        });
    }

    if let Some(c) = RE_JOOMLA_GENERATOR.captures(body) {
        let ver = c.get(1).map(|m| m.as_str().trim().to_string()).filter(|s| !s.is_empty());
        findings.push(TechFinding {
            product: "joomla".to_string(),
            confidence: "high".to_string(),
            evidence: vec!["meta_generator:Joomla".to_string()],
            version: ver,
        });
    }

    if RE_DRUPAL.is_match(body) {
        // Low confidence unless stronger indicators are added.
        findings.push(TechFinding {
            product: "drupal".to_string(),
            confidence: "low".to_string(),
            evidence: vec!["keyword:Drupal".to_string()],
            version: None,
        });
    }

    // SPA frameworks: low/medium confidence based on markers
    if RE_NEXTJS.is_match(body) {
        findings.push(TechFinding {
            product: "nextjs".to_string(),
            confidence: "medium".to_string(),
            evidence: vec!["marker:__NEXT_DATA__".to_string()],
            version: None,
        });
    }

    // script src hints
    let script_sel = Selector::parse("script[src]").unwrap();
    let mut srcs = Vec::new();
    for s in doc.select(&script_sel) {
        if let Some(src) = s.value().attr("src") {
            srcs.push(src.to_string());
        }
    }

    for src in &srcs {
        let sl = src.to_lowercase();
        if sl.contains("wp-includes") || sl.contains("wp-content") {
            findings.push(TechFinding {
                product: "wordpress".to_string(),
                confidence: "medium".to_string(),
                evidence: vec![format!("script_src:{src}")],
                version: None,
            });
        }
        if sl.contains("react") {
            findings.push(TechFinding {
                product: "react".to_string(),
                confidence: "low".to_string(),
                evidence: vec![format!("script_src:{src}")],
                version: None,
            });
        }
        if sl.contains("vue") {
            findings.push(TechFinding {
                product: "vue".to_string(),
                confidence: "low".to_string(),
                evidence: vec![format!("script_src:{src}")],
                version: None,
            });
        }
    }

    // Keyword fallback
    if RE_REACT.is_match(body) {
        findings.push(TechFinding {
            product: "react".to_string(),
            confidence: "low".to_string(),
            evidence: vec!["keyword:react".to_string()],
            version: None,
        });
    }
    if RE_VUE.is_match(body) {
        findings.push(TechFinding {
            product: "vue".to_string(),
            confidence: "low".to_string(),
            evidence: vec!["keyword:vue".to_string()],
            version: None,
        });
    }

    findings
}

fn dedupe_and_merge(findings: Vec<TechFinding>) -> Vec<TechFinding> {
    // Merge by product; keep best confidence and aggregate evidence.
    fn score_conf(c: &str) -> i32 {
        match c {
            "high" => 3,
            "medium" => 2,
            _ => 1,
        }
    }

    let mut map: BTreeMap<String, TechFinding> = BTreeMap::new();
    for f in findings {
        map.entry(f.product.clone())
            .and_modify(|cur| {
                // confidence
                if score_conf(&f.confidence) > score_conf(&cur.confidence) {
                    cur.confidence = f.confidence.clone();
                }
                // version
                if cur.version.is_none() {
                    cur.version = f.version.clone();
                }
                // evidence
                let mut s: BTreeSet<String> = cur.evidence.iter().cloned().collect();
                for e in &f.evidence {
                    s.insert(e.clone());
                }
                cur.evidence = s.into_iter().collect();
            })
            .or_insert(f);
    }
    map.into_values().collect()
}

pub fn load_cve_db(path: &Path) -> Result<CveDb> {
    let bytes = std::fs::read(path).with_context(|| format!("read {}", path.display()))?;
    let db: CveDb = serde_json::from_slice(&bytes).context("parse cve db json")?;
    Ok(db)
}

fn map_exposures(tech: &[TechFinding], db: &CveDb) -> Result<Vec<ExposureFinding>> {
    let mut out = Vec::new();

    for t in tech {
        let mut matches = Vec::new();
        for e in &db.entries {
            if e.product != t.product {
                continue;
            }

            let ok = match (&e.r#match.version_regex, &t.version) {
                (Some(vre), Some(v)) => {
                    let re = Regex::new(vre)
                        .with_context(|| format!("bad version_regex for {}", e.product))?;
                    re.is_match(v)
                }
                (Some(_), None) => false,
                (None, _) => true,
            };

            if ok {
                matches.extend(e.cves.clone());
            }
        }

        if !matches.is_empty() {
            out.push(ExposureFinding {
                product: t.product.clone(),
                detected_version: t.version.clone(),
                matches,
                note: "Possible exposure based on local mapping only (no exploitation performed). Verify versions and applicability.".to_string(),
            });
        }
    }

    Ok(out)
}

pub fn fingerprint_url(url: &str, timeout_secs: u64, max_bytes: usize, cve_db: Option<&Path>) -> Result<FingerprintReport> {
    let parsed = Url::parse(url).or_else(|_| Url::parse(&format!("https://{url}")))?;

    let client = reqwest::blocking::Client::builder()
        .redirect(reqwest::redirect::Policy::limited(8))
        .timeout(std::time::Duration::from_secs(timeout_secs))
        .user_agent("apkchisel3/fingerprint (Khaninkali)")
        .build()?;

    let mut warnings = Vec::new();

    let mut resp = client.get(parsed.as_str()).send()?;
    let status = resp.status().as_u16();

    let final_url = resp.url().to_string();
    let headers = header_map(&resp);

    let mut body_bytes = Vec::new();
    resp.copy_to(&mut body_bytes)
        .with_context(|| format!("read body from {final_url}"))?;
    if body_bytes.len() > max_bytes {
        warnings.push(format!("body_truncated:{}>{}", body_bytes.len(), max_bytes));
        body_bytes.truncate(max_bytes);
    }

    let body = String::from_utf8_lossy(&body_bytes).to_string();
    let doc = Html::parse_document(&body);
    let title = extract_title(&doc);

    let mut findings = Vec::new();
    findings.extend(detect_from_headers(&headers));
    findings.extend(detect_from_html(&body, &doc));
    let tech = dedupe_and_merge(findings);

    let possible_exposure = if let Some(p) = cve_db {
        let db = load_cve_db(p)?;
        map_exposures(&tech, &db)?
    } else {
        Vec::new()
    };

    if status == 0 {
        warnings.push("no_status".to_string());
    }

    Ok(FingerprintReport {
        author: "Khaninkali (HyperSecurity)".to_string(),
        url: parsed.to_string(),
        final_url,
        status,
        headers,
        title,
        tech,
        possible_exposure,
        warnings,
    })
}
