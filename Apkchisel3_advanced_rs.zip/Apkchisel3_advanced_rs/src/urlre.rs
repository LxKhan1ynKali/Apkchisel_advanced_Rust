use anyhow::{Context, Result};
use regex::Regex;
use serde::Serialize;
use std::net::IpAddr;
use std::path::Path;
use url::Url;

#[derive(Debug, Serialize)]
pub struct UrlIndicators {
    pub original: String,
    pub normalized: Option<String>,

    pub scheme: Option<String>,
    pub host_raw: Option<String>,
    pub host_unicode: Option<String>,
    pub host_ascii: Option<String>,
    pub port: Option<u16>,
    pub path: Option<String>,
    pub query_len: Option<usize>,
    pub fragment_present: bool,

    pub registrable_domain: Option<String>,
    pub public_suffix: Option<String>,
    pub subdomain: Option<String>,

    pub flags: Vec<String>,
    pub score: i32,
}

fn naive_domain_parts(host: &str) -> (Option<String>, Option<String>, Option<String>) {
    // Very lightweight heuristic (NOT PSL-aware):
    // - suffix: last label
    // - registrable: last two labels
    // - subdomain: everything before registrable
    let labels: Vec<&str> = host.split('.').filter(|s| !s.is_empty()).collect();
    if labels.len() < 2 {
        return (None, None, None);
    }
    let public_suffix = Some(labels[labels.len() - 1].to_string());
    let registrable_domain = Some(format!("{}.{}", labels[labels.len() - 2], labels[labels.len() - 1]));
    let subdomain = if labels.len() > 2 {
        Some(labels[..labels.len() - 2].join("."))
    } else {
        None
    };
    (subdomain, registrable_domain, public_suffix)
}

fn is_private_ip(ip: IpAddr) -> bool {
    match ip {
        IpAddr::V4(v4) => {
            let o = v4.octets();
            o[0] == 10
                || (o[0] == 172 && (16..=31).contains(&o[1]))
                || (o[0] == 192 && o[1] == 168)
                || o[0] == 127
        }
        IpAddr::V6(v6) => v6.is_loopback() || v6.is_unique_local() || v6.is_unspecified(),
    }
}

/// Parse URL with a couple of normalization tricks:
/// - if scheme is missing, assume http://
pub fn analyze_url(input: &str) -> Result<UrlIndicators> {
    let trimmed = input.trim();
    let with_scheme = if trimmed.contains("://") {
        trimmed.to_string()
    } else {
        format!("http://{}", trimmed)
    };

    let url = Url::parse(&with_scheme)
        .with_context(|| format!("failed to parse URL: {with_scheme}"))?;

    let scheme = Some(url.scheme().to_string());
    let host_raw = url.host_str().map(|s| s.to_string());
    let port = url.port_or_known_default();
    let path = Some(url.path().to_string());
    let query_len = url.query().map(|q| q.len());
    let fragment_present = url.fragment().is_some();

    let mut flags = Vec::new();
    let mut score = 0;

    // Hostname IDN handling
    let (host_unicode, host_ascii) = if let Some(h) = url.host_str() {
        // ascii form (punycode) - url crate already uses ascii internally, but keep explicit
        let ascii = idna::domain_to_ascii(h).ok();
        let unicode = idna::domain_to_unicode(h).0.into();
        (Some(unicode), ascii)
    } else {
        (None, None)
    };

    if scheme.as_deref() == Some("http") {
        flags.push("insecure_scheme_http".to_string());
        score += 3;
    }

    // Heuristics around host
    if let Some(h) = url.host_str() {
        // IP in host
        if let Ok(ip) = h.parse::<IpAddr>() {
            flags.push("host_is_ip".to_string());
            score += 6;
            if is_private_ip(ip) {
                flags.push("host_is_private_ip".to_string());
                score += 2;
            }
        }

        // @ in URL (userinfo) is often abused
        if url.username() != "" {
            flags.push("userinfo_present".to_string());
            score += 8;
        }

        // Many subdomains
        let dot_count = h.matches('.').count();
        if dot_count >= 4 {
            flags.push("many_subdomains".to_string());
            score += 4;
        }

        // Suspicious characters
        if h.contains('-') {
            flags.push("hyphen_in_host".to_string());
            score += 1;
        }
        if h.chars().any(|c| c.is_ascii_digit()) {
            flags.push("digits_in_host".to_string());
            score += 1;
        }

        // Unicode confusables (cheap heuristic): host changes between unicode and ascii
        if let (Some(u), Some(a)) = (&host_unicode, &host_ascii) {
            if u != a {
                flags.push("idn_or_punycode_host".to_string());
                score += 3;
            }
        }

        // Registrable-domain parsing (offline, lightweight heuristic):
        // This is NOT equivalent to the full Public Suffix List, but avoids network fetches.
        let (subdomain, registrable_domain, public_suffix) = naive_domain_parts(h);

        if registrable_domain.is_none() {
            flags.push("no_registrable_domain".to_string());
            score += 5;
        }

        if let Some(ps) = &public_suffix {
            let risky = ["zip", "mov", "top", "xyz", "click", "cam", "live"];
            if risky.iter().any(|t| ps.ends_with(t)) {
                flags.push("risky_tld".to_string());
                score += 3;
            }
        }

        return Ok(UrlIndicators {
            original: trimmed.to_string(),
            normalized: Some(url.to_string()),
            scheme,
            host_raw,
            host_unicode,
            host_ascii,
            port,
            path,
            query_len,
            fragment_present,
            registrable_domain,
            public_suffix,
            subdomain,
            flags,
            score,
        });
    }

    // Path / query heuristics
    let suspicious_enc = Regex::new(r"%[0-9a-fA-F]{2}")?;
    if suspicious_enc.is_match(url.path()) {
        flags.push("percent_encoding_in_path".to_string());
        score += 2;
    }
    if let Some(q) = url.query() {
        if q.len() > 120 {
            flags.push("long_query".to_string());
            score += 3;
        }
        if suspicious_enc.is_match(q) {
            flags.push("percent_encoding_in_query".to_string());
            score += 1;
        }
    }

    Ok(UrlIndicators {
        original: trimmed.to_string(),
        normalized: Some(url.to_string()),
        scheme,
        host_raw,
        host_unicode,
        host_ascii,
        port,
        path,
        query_len,
        fragment_present,
        registrable_domain: None,
        public_suffix: None,
        subdomain: None,
        flags,
        score,
    })
}

#[derive(Debug, Serialize)]
pub struct TyposquatResult {
    pub candidate: String,
    pub brands: Vec<String>,
    pub best_match: Option<String>,
    pub distance: Option<usize>,
    pub notes: Vec<String>,
    pub score: i32,
}

fn levenshtein(a: &str, b: &str) -> usize {
    let mut costs: Vec<usize> = (0..=b.len()).collect();
    for (i, ca) in a.chars().enumerate() {
        let mut last = i;
        costs[0] = i + 1;
        for (j, cb) in b.chars().enumerate() {
            let new = if ca == cb {
                last
            } else {
                1 + last.min(costs[j]).min(costs[j + 1])
            };
            last = costs[j + 1];
            costs[j + 1] = new;
        }
    }
    costs[b.len()]
}

fn normalize_host_like(s: &str) -> String {
    s.trim()
        .to_lowercase()
        .trim_start_matches("http://")
        .trim_start_matches("https://")
        .trim_end_matches('/')
        .to_string()
}

pub fn typosquat_check(candidate: &str, brands: &[String]) -> TyposquatResult {
    let cand = normalize_host_like(candidate);

    let mut best: Option<(String, usize)> = None;
    for b in brands {
        let bn = normalize_host_like(b);
        let d = levenshtein(&cand, &bn);
        if best.as_ref().map(|x| d < x.1).unwrap_or(true) {
            best = Some((bn, d));
        }
    }

    let mut notes = Vec::new();
    let mut score = 0;

    // Cheap substitutions commonly used
    let subs = [("0", "o"), ("1", "l"), ("rn", "m"), ("vv", "w")];
    for (a, b) in subs {
        if cand.contains(a) {
            notes.push(format!("contains_substitution_like:{a}->{b}"));
            score += 2;
        }
    }

    if cand.matches('-').count() >= 2 {
        notes.push("many_hyphens".to_string());
        score += 1;
    }

    let (best_match, distance) = match best {
        Some((m, d)) => {
            if d <= 2 {
                notes.push("very_close_to_known_brand".to_string());
                score += 7;
            } else if d <= 4 {
                notes.push("close_to_known_brand".to_string());
                score += 4;
            }
            (Some(m), Some(d))
        }
        None => (None, None),
    };

    TyposquatResult {
        candidate: cand,
        brands: brands.to_vec(),
        best_match,
        distance,
        notes,
        score,
    }
}

#[derive(Debug, Serialize)]
pub struct FetchMeta {
    pub url: String,
    pub chain: Vec<FetchHop>,
    pub final_url: Option<String>,
    pub warnings: Vec<String>,
}

#[derive(Debug, Serialize)]
pub struct FetchHop {
    pub url: String,
    pub status: u16,
    pub location: Option<String>,
    pub server: Option<String>,
    pub content_type: Option<String>,
    pub content_length: Option<u64>,
}

pub fn fetch_metadata(start: &str, max_hops: usize, timeout_secs: u64) -> Result<FetchMeta> {
    let client = reqwest::blocking::Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .timeout(std::time::Duration::from_secs(timeout_secs))
        .user_agent("apkchisel3/defensive-metadata-fetch")
        .build()?
        ;

    let mut warnings = Vec::new();
    let mut chain = Vec::new();

    let mut current = start.to_string();

    for _ in 0..max_hops {
        let resp = client.head(&current).send().or_else(|_| client.get(&current).send())?;
        let status = resp.status().as_u16();
        let headers = resp.headers().clone();

        let location = headers
            .get(reqwest::header::LOCATION)
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());

        let server = headers
            .get(reqwest::header::SERVER)
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());

        let content_type = headers
            .get(reqwest::header::CONTENT_TYPE)
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());

        let content_length = headers
            .get(reqwest::header::CONTENT_LENGTH)
            .and_then(|v| v.to_str().ok())
            .and_then(|s| s.parse::<u64>().ok());

        chain.push(FetchHop {
            url: current.clone(),
            status,
            location: location.clone(),
            server,
            content_type,
            content_length,
        });

        // follow redirects manually
        if (300..400).contains(&status) {
            if let Some(loc) = location {
                // resolve relative redirects
                let base = Url::parse(&current)?;
                let next = base.join(&loc).unwrap_or_else(|_| loc.parse::<Url>().unwrap_or(base));
                current = next.to_string();
                continue;
            } else {
                warnings.push("redirect_status_without_location".to_string());
                break;
            }
        }

        // Non-redirect final
        return Ok(FetchMeta {
            url: start.to_string(),
            chain,
            final_url: Some(current),
            warnings,
        });
    }

    warnings.push("max_hops_reached".to_string());
    Ok(FetchMeta {
        url: start.to_string(),
        chain,
        final_url: None,
        warnings,
    })
}

pub fn write_json<P: AsRef<Path>, T: Serialize>(path: P, v: &T) -> Result<()> {
    let bytes = serde_json::to_vec_pretty(v)?;
    std::fs::write(&path, bytes).with_context(|| format!("write {}", path.as_ref().display()))?;
    Ok(())
}
