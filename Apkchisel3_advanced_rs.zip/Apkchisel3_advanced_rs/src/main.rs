use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use std::path::PathBuf;

mod banner;
mod fingerprint;
mod report;
mod tools;
mod urlre;
mod webre;
mod zipops;

#[derive(Parser, Debug)]
#[command(name = "chiselv3")]
#[command(about = "Defensive APK/IPA reverse-engineering helper (Khaninkali / HyperSecurity)")]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand, Debug)]
enum Command {
    /// List contents of an APK/IPA (ZIP)
    List {
        /// Path to .apk or .ipa
        #[arg(short, long)]
        input: PathBuf,
    },

    /// Extract an APK/IPA (ZIP) to a directory
    Extract {
        /// Path to .apk or .ipa
        #[arg(short, long)]
        input: PathBuf,

        /// Output directory
        #[arg(short, long)]
        out: PathBuf,
    },

    /// Compute SHA-256 for a single file
    Hash {
        #[arg(short, long)]
        input: PathBuf,
    },

    /// Scan artifact and produce JSON report (and optionally run external tools)
    Scan {
        /// Path to .apk or .ipa
        #[arg(short, long)]
        input: PathBuf,

        /// Output directory for analysis artifacts
        #[arg(short, long)]
        out: PathBuf,

        /// Run external tools if installed (apktool/jadx/yara)
        #[arg(long, default_value_t = true)]
        external: bool,

        /// Optional YARA rules file (requires `yara` on PATH)
        #[arg(long)]
        yara_rules: Option<PathBuf>,
    },

    /// Defensive URL reverse-engineering (phishing indicator extraction)
    UrlAnalyze {
        /// URL to analyze
        #[arg(short, long)]
        url: String,

        /// Optional JSON output path
        #[arg(long)]
        json_out: Option<PathBuf>,
    },

    /// Defensive typosquatting check against an allow-list of brands/domains
    TyposquatCheck {
        /// Candidate domain/host (or full URL)
        #[arg(short, long)]
        candidate: String,

        /// Brand domains to compare against (repeatable)
        #[arg(long = "brand")]
        brands: Vec<String>,

        /// Optional JSON output path
        #[arg(long)]
        json_out: Option<PathBuf>,
    },

    /// Fetch HTTP metadata only (headers + redirect chain). No form submissions.
    FetchMeta {
        /// URL to fetch
        #[arg(short, long)]
        url: String,

        /// Max redirects to follow
        #[arg(long, default_value_t = 8)]
        max_hops: usize,

        /// Timeout seconds per request
        #[arg(long, default_value_t = 12)]
        timeout_secs: u64,

        /// Optional JSON output path
        #[arg(long)]
        json_out: Option<PathBuf>,
    },

    /// Static HTML analysis (forms, redirects, extracted links) with strict size limits
    HtmlAnalyze {
        /// URL to fetch/analyze
        #[arg(short, long)]
        url: String,

        /// Max bytes to read from response body
        #[arg(long, default_value_t = 1024 * 1024)]
        max_bytes: usize,

        /// Timeout seconds per request
        #[arg(long, default_value_t = 12)]
        timeout_secs: u64,

        /// Optional JSON output path
        #[arg(long)]
        json_out: Option<PathBuf>,
    },

    /// Export IOCs (URL/domain/IP) from a URL into CSV/JSON (defensive)
    IocExport {
        /// URL to extract IOCs from
        #[arg(short, long)]
        url: String,

        /// Output CSV path
        #[arg(long)]
        csv_out: Option<PathBuf>,

        /// Output JSON path
        #[arg(long)]
        json_out: Option<PathBuf>,
    },

    /// Tech fingerprinting (headers + HTML hints) and optional local CVE mapping (defensive)
    Fingerprint {
        /// URL to fingerprint
        #[arg(short, long)]
        url: String,

        /// Timeout seconds
        #[arg(long, default_value_t = 15)]
        timeout_secs: u64,

        /// Max bytes to read from HTML response
        #[arg(long, default_value_t = 1024 * 1024)]
        max_bytes: usize,

        /// Optional local CVE mapping JSON file (see cve_map.json template)
        #[arg(long)]
        cve_db: Option<PathBuf>,

        /// Optional JSON output path
        #[arg(long)]
        json_out: Option<PathBuf>,
    },
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    banner::print();

    match cli.command {
        Command::List { input } => {
            let entries = zipops::list_zip(&input)
                .with_context(|| format!("listing archive: {}", input.display()))?;
            for e in entries {
                println!("{}\t{}\t{}", e.size, e.compressed_size, e.name);
            }
        }
        Command::Extract { input, out } => {
            zipops::extract_zip(&input, &out)
                .with_context(|| format!("extracting {} -> {}", input.display(), out.display()))?;
            println!("Extracted to {}", out.display());
        }
        Command::Hash { input } => {
            let h = tools::sha256_file(&input)
                .with_context(|| format!("hashing {}", input.display()))?;
            println!("{}  {}", h, input.display());
        }
        Command::Scan {
            input,
            out,
            external,
            yara_rules,
        } => {
            std::fs::create_dir_all(&out)
                .with_context(|| format!("creating output dir: {}", out.display()))?;

            let scan = report::scan(&input, &out, external, yara_rules.as_deref())
                .with_context(|| "scan failed")?;

            let report_path = out.join("report.json");
            std::fs::write(&report_path, serde_json::to_vec_pretty(&scan)?)
                .with_context(|| format!("writing {}", report_path.display()))?;

            println!("Wrote {}", report_path.display());
        }

        Command::UrlAnalyze { url, json_out } => {
            let r = urlre::analyze_url(&url)?;
            if let Some(p) = json_out {
                urlre::write_json(p, &r)?;
            } else {
                println!("{}", serde_json::to_string_pretty(&r)?);
            }
        }

        Command::TyposquatCheck {
            candidate,
            brands,
            json_out,
        } => {
            let r = urlre::typosquat_check(&candidate, &brands);
            if let Some(p) = json_out {
                urlre::write_json(p, &r)?;
            } else {
                println!("{}", serde_json::to_string_pretty(&r)?);
            }
        }

        Command::FetchMeta {
            url,
            max_hops,
            timeout_secs,
            json_out,
        } => {
            let r = urlre::fetch_metadata(&url, max_hops, timeout_secs)?;
            if let Some(p) = json_out {
                urlre::write_json(p, &r)?;
            } else {
                println!("{}", serde_json::to_string_pretty(&r)?);
            }
        }

        Command::HtmlAnalyze {
            url,
            max_bytes,
            timeout_secs,
            json_out,
        } => {
            let r = webre::analyze_html(&url, max_bytes, timeout_secs)?;
            if let Some(p) = json_out {
                urlre::write_json(p, &r)?;
            } else {
                println!("{}", serde_json::to_string_pretty(&r)?);
            }
        }

        Command::IocExport {
            url,
            csv_out,
            json_out,
        } => {
            let r = webre::iocs_from_url(&url)?;
            if let Some(p) = &json_out {
                urlre::write_json(p, &r)?;
            }
            if let Some(p) = &csv_out {
                webre::write_iocs_csv(p, &r)?;
            }
            if json_out.is_none() && csv_out.is_none() {
                println!("{}", serde_json::to_string_pretty(&r)?);
            }
        }

        Command::Fingerprint {
            url,
            timeout_secs,
            max_bytes,
            cve_db,
            json_out,
        } => {
            let r = fingerprint::fingerprint_url(&url, timeout_secs, max_bytes, cve_db.as_deref())?;
            if let Some(p) = json_out {
                urlre::write_json(p, &r)?;
            } else {
                println!("{}", serde_json::to_string_pretty(&r)?);
            }
        }
    }

    Ok(())
}
