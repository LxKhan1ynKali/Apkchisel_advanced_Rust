use anyhow::{Context, Result};
use std::fs::File;
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone)]
pub struct ZipEntry {
    pub name: String,
    pub size: u64,
    pub compressed_size: u64,
}

pub fn list_zip(path: &Path) -> Result<Vec<ZipEntry>> {
    let f = File::open(path).with_context(|| format!("open {}", path.display()))?;
    let mut zip = zip::ZipArchive::new(f).context("parse zip")?;

    let mut entries = Vec::with_capacity(zip.len());
    for i in 0..zip.len() {
        let file = zip.by_index(i)?;
        entries.push(ZipEntry {
            name: file.name().to_string(),
            size: file.size(),
            compressed_size: file.compressed_size(),
        });
    }
    Ok(entries)
}

pub fn extract_zip(path: &Path, out_dir: &Path) -> Result<Vec<PathBuf>> {
    let f = File::open(path).with_context(|| format!("open {}", path.display()))?;
    let mut zip = zip::ZipArchive::new(f).context("parse zip")?;

    std::fs::create_dir_all(out_dir)
        .with_context(|| format!("mkdir {}", out_dir.display()))?;

    let mut written = Vec::new();

    for i in 0..zip.len() {
        let mut file = zip.by_index(i)?;
        let name = file
            .enclosed_name()
            .map(|p| p.to_owned())
            .context("zip entry has invalid path")?;

        let out_path = out_dir.join(name);

        if file.name().ends_with('/') {
            std::fs::create_dir_all(&out_path)
                .with_context(|| format!("mkdir {}", out_path.display()))?;
            continue;
        }

        if let Some(parent) = out_path.parent() {
            std::fs::create_dir_all(parent)
                .with_context(|| format!("mkdir {}", parent.display()))?;
        }

        let mut out = File::create(&out_path)
            .with_context(|| format!("create {}", out_path.display()))?;
        io::copy(&mut file, &mut out)
            .with_context(|| format!("write {}", out_path.display()))?;

        written.push(out_path);
    }

    Ok(written)
}
