use crate::tools;
use crate::zipops;
use anyhow::{Context, Result};
use serde::Serialize;
use std::path::Path;
use time::{format_description::well_known::Rfc3339, OffsetDateTime};

#[derive(Debug, Serialize)]
pub struct ExternalRun {
    pub tool: String,
    pub ok: bool,
    pub output_file: Option<String>,
    pub note: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct ScanReport {
    pub author: String,
    pub generated_at: String,
    pub input: String,
    pub input_sha256: String,
    pub kind: String,
    pub zip_entries: usize,
    pub extracted_dir: Option<String>,
    pub extracted_file_count: Option<usize>,
    pub extracted_hashes: Option<Vec<(String, String)>>,
    pub external: Vec<ExternalRun>,
    pub warnings: Vec<String>,
}

pub fn scan(input: &Path, out_dir: &Path, external: bool, yara_rules: Option<&Path>) -> Result<ScanReport> {
    let now = OffsetDateTime::now_utc().format(&Rfc3339)?;

    let kind = match tools::ext(input).unwrap_or("") {
        "apk" => "apk",
        "ipa" => "ipa",
        _ => "zip",
    };

    let input_sha256 = tools::sha256_file(input)?;

    let entries = zipops::list_zip(input)
        .with_context(|| format!("list zip {}", input.display()))?;

    // Always extract (defensive; enables hashing). If you want optional extraction, we can add a flag.
    let extracted = out_dir.join("extracted");
    let written = zipops::extract_zip(input, &extracted)
        .with_context(|| format!("extract {}", input.display()))?;

    let extracted_hashes = tools::sha256_tree(&extracted)
        .context("hash extracted tree")?
        .into_iter()
        .map(|(p, h)| {
            let rel = p.strip_prefix(&extracted).unwrap_or(&p);
            (rel.display().to_string(), h)
        })
        .collect::<Vec<_>>();

    let mut warnings = Vec::new();
    if kind == "apk" {
        if !entries.iter().any(|e| e.name == "AndroidManifest.xml") {
            warnings.push("APK missing AndroidManifest.xml (unusual)".to_string());
        }
        if entries.iter().any(|e| e.name.ends_with(".so")) {
            warnings.push("APK contains native .so libraries (review for embedded native code)".to_string());
        }
    }

    let mut external_runs = Vec::new();
    if external {
        let logs = out_dir.join("logs");
        std::fs::create_dir_all(&logs).context("mkdir logs")?;

        // apktool
        if kind == "apk" {
            if tools::which("apktool") {
                let apktool_out = out_dir.join("apktool_out");
                std::fs::create_dir_all(&apktool_out).ok();
                let log_file = logs.join("apktool.txt");
                let apk_s = input.to_string_lossy().to_string();
                let out_s = apktool_out.to_string_lossy().to_string();
                let args = vec!["d".to_string(), apk_s, "-o".to_string(), out_s, "-f".to_string()];
                let ok = tools::run_to_file_owned("apktool", &args, &log_file).is_ok();
                external_runs.push(ExternalRun {
                    tool: "apktool".to_string(),
                    ok,
                    output_file: Some(log_file.display().to_string()),
                    note: None,
                });
            } else {
                external_runs.push(ExternalRun {
                    tool: "apktool".to_string(),
                    ok: false,
                    output_file: None,
                    note: Some("not found on PATH".to_string()),
                });
            }

            // jadx
            if tools::which("jadx") {
                let jadx_out = out_dir.join("jadx");
                std::fs::create_dir_all(&jadx_out).ok();
                let log_file = logs.join("jadx.txt");
                let out_s = jadx_out.to_string_lossy().to_string();
                let apk_s = input.to_string_lossy().to_string();
                let args = vec!["-d".to_string(), out_s, apk_s];
                let ok = tools::run_to_file_owned("jadx", &args, &log_file).is_ok();
                external_runs.push(ExternalRun {
                    tool: "jadx".to_string(),
                    ok,
                    output_file: Some(log_file.display().to_string()),
                    note: None,
                });
            } else {
                external_runs.push(ExternalRun {
                    tool: "jadx".to_string(),
                    ok: false,
                    output_file: None,
                    note: Some("not found on PATH".to_string()),
                });
            }
        }

        // yara (optional)
        if let Some(rules) = yara_rules {
            if tools::which("yara") {
                let log_file = logs.join("yara.txt");
                let rules_s = rules.to_string_lossy().to_string();
                let extracted_s = extracted.to_string_lossy().to_string();
                let args = vec!["-r".to_string(), rules_s, extracted_s];
                let ok = tools::run_to_file_owned("yara", &args, &log_file).is_ok();
                external_runs.push(ExternalRun {
                    tool: "yara".to_string(),
                    ok,
                    output_file: Some(log_file.display().to_string()),
                    note: None,
                });
            } else {
                external_runs.push(ExternalRun {
                    tool: "yara".to_string(),
                    ok: false,
                    output_file: None,
                    note: Some("not found on PATH".to_string()),
                });
            }
        }
    }

    Ok(ScanReport {
        author: "Khaninkali (HyperSecurity)".to_string(),
        generated_at: now,
        input: input.display().to_string(),
        input_sha256,
        kind: kind.to_string(),
        zip_entries: entries.len(),
        extracted_dir: Some(extracted.display().to_string()),
        extracted_file_count: Some(written.len()),
        extracted_hashes: Some(extracted_hashes),
        external: external_runs,
        warnings,
    })
}
