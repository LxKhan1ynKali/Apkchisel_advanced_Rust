use anyhow::{Context, Result};
use sha2::{Digest, Sha256};
use std::ffi::OsStr;
use std::fs::File;
use std::io::{BufReader, Read};
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use walkdir::WalkDir;

pub fn sha256_file(path: &Path) -> Result<String> {
    let f = File::open(path).with_context(|| format!("open {}", path.display()))?;
    let mut r = BufReader::new(f);
    let mut h = Sha256::new();

    let mut buf = [0u8; 1024 * 64];
    loop {
        let n = r.read(&mut buf)?;
        if n == 0 {
            break;
        }
        h.update(&buf[..n]);
    }

    Ok(format!("{:x}", h.finalize()))
}

pub fn sha256_tree(dir: &Path) -> Result<Vec<(PathBuf, String)>> {
    let mut out = Vec::new();
    for ent in WalkDir::new(dir).follow_links(false) {
        let ent = ent?;
        if ent.file_type().is_file() {
            let p = ent.path().to_path_buf();
            out.push((p.clone(), sha256_file(&p)?));
        }
    }
    out.sort_by(|a, b| a.0.cmp(&b.0));
    Ok(out)
}

pub fn which(cmd: &str) -> bool {
    Command::new("sh")
        .arg("-lc")
        .arg(format!("command -v {} >/dev/null 2>&1", cmd))
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

pub fn run(cmd: &str, args: &[&str]) -> Result<Output> {
    Command::new(cmd)
        .args(args)
        .output()
        .with_context(|| format!("run {} {:?}", cmd, args))
}

pub fn run_to_file(cmd: &str, args: &[&str], out_path: &Path) -> Result<()> {
    let out = run(cmd, args)?;
    write_output(out, out_path)
}

pub fn run_to_file_owned(cmd: &str, args: &[String], out_path: &Path) -> Result<()> {
    let out = Command::new(cmd)
        .args(args)
        .output()
        .with_context(|| format!("run {} {:?}", cmd, args))?;
    write_output(out, out_path)
}

fn write_output(out: Output, out_path: &Path) -> Result<()> {
    let mut buf = Vec::new();
    buf.extend_from_slice(&out.stdout);
    buf.extend_from_slice(b"\n--- STDERR ---\n");
    buf.extend_from_slice(&out.stderr);
    std::fs::write(out_path, buf)
        .with_context(|| format!("write {}", out_path.display()))?;
    Ok(())
}

pub fn ext(path: &Path) -> Option<&str> {
    path.extension().and_then(OsStr::to_str)
}
