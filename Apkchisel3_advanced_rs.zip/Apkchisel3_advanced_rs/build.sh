#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST="$PROJECT_DIR/Cargo.toml"

echo "[+] Building (release): $MANIFEST"
cargo build --release --manifest-path "$MANIFEST"

BIN_SRC="$PROJECT_DIR/target/release/chiselv3"
BIN_DIR="$PROJECT_DIR/binaries"
BIN_DST="$BIN_DIR/chiselv3"

mkdir -p "$BIN_DIR"
cp -a "$BIN_SRC" "$BIN_DST"

echo "[+] Wrote: $BIN_DST"

echo "[+] SHA-256:"
sha256sum "$BIN_DST"
